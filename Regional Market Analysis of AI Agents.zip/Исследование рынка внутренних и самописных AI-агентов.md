# Исследование рынка внутренних и самописных AI-агентов

**Дата:** 14 августа 2026 года  
**Автор:** Manus AI  
**Охват:** США и Канада; Европа; Россия  
**Фокус:** эксплуатация, безопасность, governance и инфраструктура собственных AI-агентов

> **Ключевой вывод.** Наиболее перспективная возможность — не ещё один AI-wrapper и не общий trace dashboard, а vendor-neutral слой **Agent Control Plane**: инвентаризация агентов, граф идентичностей и разрешений, проверка MCP/A2A-интеграций, policy-as-code и runtime approval/containment. Первичный beachhead — североамериканские AI-native и SaaS-команды с 20–200 агентами; европейская версия должна усиливать auditability и data residency; российская — self-hosted/on-premise и model portability.

## Executive Summary

Исследование подтверждает исходную гипотезу: региональные различия существенны, но проходят не по линии «разные модели», а по линии **покупатель, регуляторный риск, инфраструктура, бюджет и допустимый способ поставки**. В Северной Америке strongest buying trigger связан с тем, что агенты переходят из экспериментов в production и начинают создавать расходы, инциденты и инженерную нагрузку. В Европе тот же operational problem дополнительно превращается в задачу доказуемого контроля: организации должны понимать, какие системы используются, какие данные обрабатываются и кто несёт ответственность. В России спрос заметно сильнее смещён к локальному развёртыванию, импортонезависимости, контролю стоимости inference и сопровождению heterogeneous stack.

| Регион | Главный подтверждённый паттерн | Основной покупатель | Предпочтительная поставка | Коммерческая оценка |
|---|---|---|---|---:|
| США/Канада | Быстрое масштабирование при слабой visibility, ownership и runtime control | Head of AI, Platform Engineering, CISO | Cloud-first + CLI/agent gateway | **82/100** |
| Европа | Governance, auditability, data control и vendor risk становятся частью production readiness | CISO, AI Governance, DPO, Platform Engineering | EU-hosted SaaS + private cloud/self-hosted | **74/100** |
| Россия | Локальные модели, on-premise, vendor independence и ограниченная зрелость tooling | CTO, Head of Infrastructure, крупная внутренняя IT-команда | On-premise/license/support | **59/100** |

CSA в исследовании 2026 года сообщает, что 43% организаций используют AI-агенты у более половины сотрудников, 54% имеют от 1 до 100 несогласованных агентов, только 15% обеспечивают ownership большинства агентов, 47% пережили связанный с агентом security incident, а 58% указывают срок обнаружения и реагирования не менее пяти часов [1]. Это сильное подтверждение существования боли agent inventory, shadow agents, identity, permissions и response.

В производственных командах боль смещается от «создать агента» к «доказать, что он работает предсказуемо». Исследование Cleanlab среди 1 837 респондентов нашло только 95 организаций с агентами в production; менее трети production-команд удовлетворены observability и guardrails, а 63% планируют улучшить observability/evaluation в течение следующего года [2]. Следовательно, рынок реален, но находится на ранней стадии: продавать следует не абстрактную платформу для всех, а узкий operational outcome.

В Европе AI Act создаёт самостоятельный спрос на risk-based controls, transparency, traceability и доказательства ответственности. Еврокомиссия описывает акт как комплексный правовой framework для developers и deployers, мотивированный в том числе непрозрачностью причин, по которым AI принимает решения и действия [3]. Это не означает, что любой внутренний агент автоматически относится к high-risk AI, но означает, что governance layer имеет более сильный buying trigger, чем в нерегулируемом use case.

В России данные Банка России показывают зрелый вертикальный спрос: из 252 финансовых организаций 35% уже используют ИИ постоянно, 29% тестируют пилоты, 15% планируют внедрение в течение 1–3 лет [4]. Исследование Yakov & Partners/Yandex указывает, что 46% российских компаний уже внедрили или тестируют автономные решения [5]. Однако российскую willingness to pay нельзя экстраполировать из западных SaaS-моделей: критичны on-premise, локальный inference, лицензия и интеграционный support.

## Методология и ограничения

Исследование проведено раздельно по регионам в порядке, заданном ТЗ. Использованы официальные регуляторные источники, отраслевые опросы, vendor reports, engineering materials, open-source product documentation и evidence emerging standards. Vendor-sponsored данные маркируются как **vendor evidence** и не используются в одиночку для сильных числовых выводов. Где независимых количественных данных недостаточно, оценка severity или willingness to pay обозначает **аналитическую гипотезу**, а не измеренный факт.

Минимальная единица анализа — не «функция AI», а повторяющийся процесс эксплуатации агента: кто владеет системой, какие права она имеет, как её тестируют, как расследуют сбой, как учитывают стоимость и как доказывают контроль. Это отсекает идеи, которые заменяются prompt engineering или новой функцией ChatGPT.

## Market Map: США и Канада

**Pain → Users → Current solutions → Competitors → White space → Willingness to pay**

В Северной Америке агентная разработка наиболее быстро становится частью developer platform и business operations. Adoption decentralised: разные команды используют OpenAI, Anthropic, Google, Microsoft, open-source models и собственные frameworks. Поэтому platform-specific governance быстро теряет охват. Наиболее привлекательный ICP — AI-native startup, SaaS или enterprise с 20–200 агентами, несколькими LLM providers, MCP/tools и хотя бы одним production workflow.

| Слой | Наблюдение |
|---|---|
| Pain | Agent sprawl, scope violations, silent failures, runaway cost, weak evals, unclear ownership, lack of runtime identity |
| Users | AI engineers, platform engineering, DevOps, security, developer productivity |
| Champions | Staff/Principal AI engineer, Head of Platform, CISO innovation lead |
| Buyer | VP Engineering, CTO, CISO или Head of AI |
| Current workaround | OpenTelemetry/Langfuse/Arize, spreadsheets, custom dashboards, IAM policies, scripts, incident review вручную |
| Competitors | Arize/Phoenix, Langfuse, LangSmith, Braintrust, Datadog integrations, Zenity, Prompt Security, Lakera и другие |
| White space | Cross-platform inventory + identity/permission graph + MCP/A2A posture + actionable runtime controls для mid-market |
| WTP | $500–2,000/month для команд; $2k–10k/month для regulated/multi-team; enterprise $25k–150k/year |

Главный purchase trigger — не удобство интерфейса, а снижение вероятности дорогостоящего инцидента, сокращение времени расследования, ограничение API spend и ускорение production deployment. Чистая observability уже имеет сильные OSS и commercial продукты: Arize предлагает AX для trace/eval/improve и Phoenix для локального open-source развёртывания [6]; Langfuse покрывает traces, tool calls, control flow, cost, alerts и evaluation [7]. Поэтому новый продукт должен контролировать **действие и право**, а не просто показывать trace.

## Market Map: Европа

Европа не является уменьшенной копией США. Там production readiness включает не только reliability и ROI, но и вопрос: «Можем ли мы доказать аудитору, что агент действует в пределах политики?» Для EU enterprise ключевыми становятся data lineage, model/tool provenance, ownership, human approval, retention, data residency, vendor risk и возможность private cloud.

| Слой | Наблюдение |
|---|---|
| Pain | Несоответствие между официальной AI policy и реальными tools/agents; отсутствие inventory и audit evidence; cross-border data risk |
| Users | CISO, DPO, AI governance, compliance, security architecture, platform engineering |
| Champions | AI governance lead, security architect, privacy counsel, regulated business owner |
| Buyer | CISO/Chief Risk Officer, CIO, DPO при участии CTO |
| Current workaround | GRC spreadsheets, DPIA вручную, vendor questionnaires, SIEM logs, policy documents без runtime enforcement |
| Competitors | Zenity, Prompt Security/SentinelOne, Credo AI, Holistic AI, OneTrust, Arize/Langfuse для engineering layer |
| White space | Audit-ready agent registry и evidence pipeline, который связывает policy → identity → data → tool/action → approval |
| WTP | €1k–5k/month для mid-market; €25k–200k/year enterprise; premium за EU hosting/private cloud |

Официальная страница Еврокомиссии подчёркивает risk-based obligations для AI developers и deployers и необходимость доверия, safety и fundamental rights [3]. Для продукта это означает, что «inventory» должен быть не каталогом имён, а доказуемой цепочкой: владелец, назначение, модель, данные, tools, права, human oversight, изменения и журнал действий. В Европе self-hosted и EU data residency могут быть не feature, а условием сделки.

## Market Map: Россия

Российский рынок имеет существенную агентную активность, но другую структуру покупки. Крупные банки, marketplaces, e-commerce и enterprise часто имеют сильные внутренние IT-команды и склонность строить критичный tooling самостоятельно. Это снижает привлекательность горизонтального SaaS, но повышает потенциал продукта, который поставляется как on-premise control plane, SDK или security scanner и экономит внутренние инженерные часы.

| Слой | Наблюдение |
|---|---|
| Pain | Model portability, локальный inference, GPU cost, отсутствие зрелого observability, fragmentation, security и сопровождение после ухода автора |
| Users | CTO, Head of Infrastructure, AI platform team, integrators, security, developers |
| Champions | Руководитель внутренней AI-платформы, архитектор инфраструктуры, руководитель DevSecOps |
| Buyer | CTO/CIO, директор по инфраструктуре, руководитель цифровой трансформации |
| Current workaround | Python/TypeScript scripts, n8n, Telegram bots, self-hosted RAG, локальные dashboards, собственные registries и ручные проверки |
| Competitors | Внутренние платформы банков/marketplaces, локальные LLM providers, open-source Langfuse/Phoenix, интеграторы |
| White space | Self-hosted discovery/security/observability для heterogeneous local+foreign models с поддержкой on-prem и миграции |
| WTP | 0–500 тыс. руб./мес. за командный продукт; 2–15 млн руб./год за enterprise license/support; крупные проекты — bespoke |

Банк России фиксирует регулярное применение ИИ в клиентском взаимодействии, идентификации, антифроде, аналитике и risk management [4]. Yakov & Partners/Yandex оценивают долю компаний, внедривших или тестирующих autonomous solutions, в 46% [5]. Но эти источники не доказывают, что компании готовы покупать отдельный agent-ops продукт; это ключевой вопрос для customer discovery.

## Top 20 User Pains

Оценки приведены по шкале 1–10. **Severity** — потенциальный ущерб и срочность. **WTP** — вероятность выделения бюджета именно на решение этой боли. Evidence level: A — несколько независимых первичных/официальных источников; B — один сильный отраслевой источник плюс product/engineering evidence; C — emerging signal, требующий интервью.

| № | Боль | ICP | Workaround | Частота | Severity | WTP | Evidence |
|---:|---|---|---|---|---:|---:|---|
| 1 | Компания не знает полный список агентов и shadow agents | Enterprise security/platform | Spreadsheets, IAM review, discovery scripts | постоянно | 9 | 9 | A |
| 2 | Непонятно, кто владелец агента и кто отключит его при инциденте | Enterprise, regulated | CMDB вручную, tickets | при изменениях/инциденте | 9 | 8 | A |
| 3 | Агент превышает задуманные permissions | Security, SaaS, finance, healthcare | RBAC, periodic review | постоянно | 10 | 10 | A |
| 4 | Нет machine identity и attribution действия | Platform/security | Shared service accounts, logs | каждый sensitive action | 9 | 9 | B |
| 5 | MCP server/tool подключён без полноценной проверки | Developer teams, security | Allow-lists, code review | при каждом подключении | 9 | 9 | B |
| 6 | Ошибка скрыта внутри длинного trace | AI engineering | grep logs, dashboard, manual replay | ежедневно | 8 | 8 | A |
| 7 | После смены model/prompt/tool ломается поведение | AI engineering | Golden datasets, ad hoc tests | каждый deployment | 9 | 9 | A |
| 8 | Нет regression testing и production-quality evals | AI-native startup | Custom scripts, spreadsheets | каждый release | 8 | 8 | A |
| 9 | Runaway agent создаёт неожиданный API spend | Startup, SaaS, platform | Budget alerts, billing export | ежедневно/при сбое | 8 | 8 | B |
| 10 | Невозможно распределить cost по агенту/команде/клиенту | SaaS, agencies | Manual tagging, finance spreadsheet | ежемесячно | 7 | 7 | B |
| 11 | Silent failure: агент завершает задачу правдоподобно, но неверно | Support, data, operations | Human spot checks | ежедневно | 9 | 9 | A |
| 12 | Multi-agent loops, duplicate work и recursive calls | AI platform | Hard-coded limits, manual tracing | при масштабировании | 8 | 8 | B |
| 13 | Dev→prod переносит несогласованные prompts, secrets, tools и model config | Platform engineering | YAML, CI scripts, runbooks | каждый deployment | 8 | 8 | B |
| 14 | Нет rollback/deprecation/lifecycle management | Enterprise | Tickets, owner memory | ежеквартально/при смене команды | 8 | 8 | B |
| 15 | Нельзя быстро собрать audit evidence по data/tool/action | Europe, finance, healthcare | GRC spreadsheets, screenshots | при аудите | 9 | 9 | A/B |
| 16 | Shadow AI расходится с официальной AI policy | Europe/enterprise | Policy docs, employee surveys | постоянно | 9 | 9 | A |
| 17 | Agent memory содержит устаревшие или неразрешённые данные | Healthcare, HR, CRM | Manual purge, RAG filters | ежедневно | 8 | 8 | B |
| 18 | Vendor lock-in между OpenAI/Anthropic/Gemini/local models | Russia, Europe, platform | Rewrites and adapters | при смене provider | 8 | 7 | B |
| 19 | Self-hosted inference сложен и дорог в эксплуатации | Russia, regulated | GPU team, bespoke infra | постоянно | 8 | 7 | C |
| 20 | После ухода первоначального разработчика систему невозможно сопровождать | Russia, SMB/enterprise | Reverse engineering, consultant | при turnover | 8 | 7 | C |

### Почему эти боли реальны

CSA даёт независимое от конкретной framework подтверждение масштабируемой проблемы контроля: shadow agents, scope violations, incidents, ownership gaps и долгий response [1]. Cleanlab подтверждает production gap на уровне reliability, observability, evaluation и stack churn [2]. Engineering documentation Langfuse показывает, что в agent trace нужно сохранять не только ответ модели, но и tools, control flow, context, cost и subagent handoffs [7]. Официальные MCP/A2A материалы демонстрируют, что tool access, authorization, capability discovery и межагентные task lifecycles становятся стандартизованными, но не автоматически безопасными [8] [9]. В России отраслевые источники подтверждают рост применения, особенно в финансовом секторе и крупных корпорациях [4] [5].

## Existing Solutions и white spaces

| Категория | Уже существует | Что закрыто | Что остаётся плохо решённым |
|---|---|---|---|
| LLM/agent observability | Arize AX/Phoenix, Langfuse, LangSmith, Braintrust | Traces, evals, prompt/version analytics, cost | Identity graph, action authorization, enterprise-wide discovery, policy enforcement |
| AI security/governance | Zenity, Prompt Security/SentinelOne, Lakera, CalypsoAI, Protect AI | Discovery, posture, runtime security, guardrails | Developer-first affordable product; heterogeneous on-prem; actionable remediation |
| General telemetry | OpenTelemetry, Datadog, Grafana | Logs, metrics, traces | Semantic agent risk, tool intent, permission blast radius |
| GRC/AI inventory | OneTrust, Credo AI, Holistic AI | Policy, assessments, documentation | Runtime truth and automatic evidence from code/integrations |
| IAM/PAM | Okta, Entra, CyberArk, cloud IAM | Human/service identity and secrets | Agent identity, delegated authority, intent-aware action limits |
| OSS frameworks | LangGraph, CrewAI, AutoGen, PydanticAI, n8n | Build/orchestration | Cross-framework lifecycle, governance and incident operations |

**Вывод:** observability-only — commoditizing/fragmented; enterprise AI governance — monetized but expensive and sales-heavy; agent control plane — attractive, provided the MVP starts with one narrow, high-severity workflow.

## Региональная таблица болей

| Pain | США/Канада | Европа | Россия |
|---|---:|---:|---:|
| Agent observability | 9 | 8 | 6 |
| Security | 9 | 9 | 8 |
| Governance | 8 | 10 | 7 |
| Compliance | 7 | 10 | 7 |
| Cost control | 9 | 8 | 9 |
| Testing/evals | 9 | 8 | 6 |
| Shadow AI | 9 | 10 | 6 |
| Agent inventory | 9 | 10 | 7 |
| Self-hosting | 5 | 8 | 10 |
| Model independence | 6 | 8 | 10 |
| Data residency | 6 | 10 | 9 |
| MCP security | 9 | 9 | 7 |

Оценки не означают, что одна проблема отсутствует в другом регионе. Они показывают относительную коммерческую остроту с учётом триггера покупки, regulatory pressure, масштаба deployment и допустимой модели поставки.

## Десять startup ideas

| № | Идея | Beachhead | Региональный fit | Big Tech risk | Opportunity |
|---:|---|---|---|---|---:|
| 1 | **Agent Control Plane**: inventory + identity/permission graph + runtime policy | US AI-native/SaaS 20–200 agents | Global core + US/EU/RU layers | Low–Medium | **87** |
| 2 | **MCP Security Gateway**: discovery, server risk, tool allow/deny, secrets and audit | Platform/security teams | US/EU first; RU on-prem | Medium | **82** |
| 3 | **Agent Regression CI**: replay golden traces across models/tools/prompts | AI engineering teams | Global | Medium | **79** |
| 4 | **Agent Cost Firewall**: budgets, routing, runaway detection, attribution | SaaS, agencies, multi-tenant | US/RU strong | Medium | **77** |
| 5 | **Audit Evidence Autopilot**: policy-to-runtime evidence for EU | EU regulated enterprise | Europe-specific | Low–Medium | **76** |
| 6 | **Self-hosted Agent Reliability Stack**: local models + tracing + evals + GPU cost | Russian banks/enterprise | Russia-specific | Low | **71** |
| 7 | **Agent Identity Broker**: machine identity and delegated authorization | Enterprise security | Global | Medium | **74** |
| 8 | **Agent Lifecycle/Registry OSS**: registry, owner, version, deprecation and kill switch | Developer/platform teams | Global developer distribution | Medium | **73** |
| 9 | **Memory Provenance Firewall**: permission-aware memory, stale-data detection, deletion | Healthcare/HR/CRM | EU/US regulated | Low–Medium | **70** |
| 10 | **Multi-agent Incident Response**: detect loops, blast radius, containment and replay | Enterprise platform/security | Global | Low | **72** |

## TOP-5 product concepts

### 1. Agent Control Plane

**One-line pitch:** Discover every internal agent, map its identity, tools, data and permissions, then enforce policy before risky actions execute.

**User and buyer.** The daily user is an AI/platform engineer and security analyst. The champion is Head of AI or Platform Engineering; buyer is VP Engineering, CTO or CISO; blocker is a team that fears instrumentation or assumes existing IAM is sufficient.

**MVP.** CLI and GitHub App scan repositories, deployment manifests, MCP configurations, API keys metadata and OpenTelemetry traces. It creates an agent inventory and graph of model → agent → identity → tool → data. The first paid control is a policy check for over-privileged tools and missing ownership, with Slack/Jira remediation workflow. Do not begin with a universal runtime proxy.

**Why now.** CSA reports decentralized adoption, shadow agents, ownership gaps and scope violations [1]. MCP formalizes tool authorization but leaves authorization optional in implementations [8]. A2A adds capability discovery and cross-agent task lifecycles [9]. The number of relationships grows faster than the number of agents, making a graph defensible.

**Competitors and gap.** Zenity and Prompt Security address enterprise AI security; Arize and Langfuse address traces/evals. The gap is a developer-first, multi-provider, reasonably priced control plane that turns discovery into actionable permission remediation and works in cloud plus self-hosted environments.

**Pricing hypothesis.** Free scanner; Team $499/month up to 50 agents; Business $1,500–3,000/month up to 500 agents; Enterprise $30k–150k/year, with private deployment as premium. These are hypotheses to validate in interviews, not observed market prices.

**Distribution and moat.** Open-source scanner, GitHub/Slack integrations, MCP registry checks and security reports. Moat: accumulated agent graph, permission-risk database, historical behavior and integrations. Big Tech risk is **Low–Medium**, because the product must govern heterogeneous non-native agents and cross-vendor tools.

### 2. MCP Security Gateway

**One-line pitch:** A policy enforcement and audit boundary for every MCP server and tool used by internal agents.

**User and buyer.** Platform/security teams; buyer CISO or Head of Infrastructure. The pain is concentrated where teams connect many third-party or internal MCP servers.

**MVP.** Reverse proxy or sidecar that inventories servers, validates identity, records tool calls, applies allow/deny policies, rate limits dangerous actions and redacts secrets. Start with HTTP MCP and provide a safe STDIO wrapper, because the specification treats these transports differently [8].

**Gap.** Generic API gateways do not understand model-selected tool intent, while agent security platforms may be too broad or enterprise-only. The risk is Medium because cloud providers and model vendors may add native controls.

**Pricing.** $299–1,500/month for teams; $25k–100k/year for enterprise; self-hosted license for Europe and Russia.

### 3. Agent Regression CI

**One-line pitch:** Replay real agent trajectories against new models, prompts and tools before they reach production.

**User and buyer.** AI engineering and developer productivity teams. Buyer is VP Engineering or Head of AI; champion is staff AI engineer.

**MVP.** Capture production traces, redact sensitive data, convert failures into golden cases, replay them in CI against provider/model versions and score tool selection, policy compliance, cost, latency and final outcome. The product must work across OpenAI, Anthropic, Gemini and local models.

**Gap.** Arize, Langfuse and other platforms already support evals [6] [7]; the opportunity is not another evaluator, but a small workflow that automatically turns production incidents into release-blocking regression tests. Big Tech risk is Medium.

**Pricing.** $199–999/month for teams, usage-based replay, enterprise $30k–120k/year.

### 4. Agent Cost Firewall

**One-line pitch:** Prevent runaway agent spend and attribute every model/tool/API dollar to the responsible agent, team and customer.

**User and buyer.** SaaS, agencies and platform teams with multi-tenant agents. Buyer CFO/CTO jointly; champion is platform engineering.

**MVP.** Provider-neutral gateway with per-agent budgets, quotas, model routing, loop detection, cost alerts and tenant attribution. Start with OpenAI/Anthropic/Gemini plus tool-call accounting.

**Gap.** Cloud billing and LLM observability show spend but usually do not stop an agent before a runaway loop. The product is strongest as an action layer over existing telemetry. Big Tech risk Medium.

**Pricing.** $99–500/month plus 1–3% of controlled spend; enterprise $25k–100k/year.

### 5. EU Audit Evidence Autopilot

**One-line pitch:** Continuously convert real agent inventory, actions and approvals into audit-ready evidence for European governance programs.

**User and buyer.** CISO, DPO, AI governance and compliance teams in EU regulated industries. Buyer is CISO/Chief Risk Officer; platform team supplies technical data.

**MVP.** Connect code repositories, model providers, MCP/A2A registries, identity systems and traces; generate an agent register, data/tool map, ownership record, change history and approval evidence. Offer EU-hosted and private-cloud deployment.

**Gap.** GRC tools manage questionnaires and policies; observability tools manage traces. The white space is continuously generated evidence connecting policy to runtime facts. Big Tech risk Low–Medium.

**Pricing.** €1,000–5,000/month; enterprise €40k–200k/year; premium for private deployment and consulting-assisted implementation.

## Региональные startup ideas и monetization

| Регион | TOP ideas | Наиболее вероятный buyer | Модель монетизации |
|---|---|---|---|
| США/Канада | Agent Control Plane; MCP Gateway; Cost Firewall; Regression CI; Agent IR | CTO/VP Eng/CISO | Usage-based SaaS, API/CLI, enterprise annual |
| Европа | Audit Evidence Autopilot; EU-hosted Control Plane; Memory Provenance; MCP Gateway; Registry | CISO/DPO/CRO | EU SaaS + private cloud + annual compliance contract |
| Россия | Self-hosted Control Plane; Model Portability Layer; Local Agent Registry; GPU Cost Firewall; Agent Support/Transfer Package | CTO/Head of Infrastructure | On-prem license, annual support, integration services |

**Region-specific opportunities** — EU Audit Evidence Autopilot и российский Self-hosted Agent Reliability Stack зависят от local regulatory/infrastructure context. **Global opportunities** — Agent Control Plane, MCP Security Gateway и Agent Regression CI. **Global core + regional layer** — один inventory/graph engine с US security/cost controls, EU audit/data residency и RU on-prem/model portability.

## Market attractiveness scoring

| Factor | США/Канада | Европа | Россия |
|---|---:|---:|---:|
| Market size | 10 | 8 | 6 |
| AI-agent adoption | 9 | 8 | 7 |
| Pain severity | 9 | 9 | 8 |
| Willingness to pay | 9 | 8 | 6 |
| Competition | 5 | 6 | 8 |
| Ease of entering | 7 | 5 | 5 |
| Sales cycle | 7 | 5 | 4 |
| Regulatory complexity | 6 | 4 | 6 |
| SaaS acceptance | 9 | 7 | 4 |
| Open-source distribution | 8 | 8 | 7 |
| **Weighted attractiveness** | **82/100** | **74/100** | **59/100** |

В строке Competition высокий балл означает мало конкуренции. В итоговой формуле применён не механический средний балл: market size, pain severity, WTP и adoption имеют больший вес, а regulatory complexity и sales cycle снижают практическую привлекательность.

## Final comparative analysis

**Где боль сильнее всего?** По raw severity — в Европе на governance/auditability и в Северной Америке на runtime security/reliability при масштабировании. В России наиболее остра комбинация self-hosting, model independence и cost control, но бюджет и продажи слабее.

**Где больше денег?** В США и Канаде: выше SaaS acceptance, enterprise budgets и плотность AI-native компаний. В Европе есть крупные бюджеты, но длиннее procurement и compliance sales. В России деньги концентрированы в крупных банках, marketplaces и enterprise, а не в широком mid-market SaaS.

**Где меньше конкурентов?** В России меньше зрелых коммерческих agent-ops vendors, но это не автоматически преимущество: часть спроса закрывается внутренними командами, интеграторами или open source. Наиболее качественный white space — не «нет конкурентов», а vendor-neutral control plane, соединяющий developer и security workflows.

**Где проще получить первые 100 пользователей?** Для OSS scanner — global developer community и Северная Америка. Для платного enterprise — локальные сети интеграторов и 2–3 вертикали в России могут дать первые design partners, но не обязательно 100 self-serve пользователей. В Европе лучше начинать с узкого compliance wedge и партнёрств.

**Где легче продать enterprise?** В США при доказанном security ROI; в Европе — при audit/regulatory trigger; в России — через крупный enterprise/on-prem проект и поддержку.

**Какие проблемы глобальны?** Inventory, ownership, permissions, tool security, reliability/evals, cost attribution, lifecycle и identity. **Какие региональны?** EU audit/data residency, Russian self-hosting/model portability и различия в procurement/payment infrastructure.

**Что Big Tech скорее закроет?** Provider-specific tracing, basic evals, model routing и basic cost dashboards. Сложнее закрыть cross-provider identity graph, organization-wide agent discovery, historical evidence, policy remediation и on-prem heterogeneity.

## Финальный выбор

### Best opportunity: США/Канада

**Agent Control Plane for AI-native and SaaS teams.** Начинать с discovery и over-permissioned tool detection, а не с полной платформы. Платёжный аргумент: уменьшить blast radius, сократить incident investigation и не дать экспериментальному агенту стать неконтролируемым production principal.

### Best opportunity: Европа

**EU Audit Evidence Autopilot.** Начинать с agent register + data/tool/owner provenance + continuous evidence export. Платёжный аргумент: сократить ручной compliance work и доказать аудитору фактический runtime control, а не только наличие policy document.

### Best opportunity: Россия

**Self-hosted Agent Control Plane для локальных и heterogeneous models.** Начинать со статического inventory, dependency graph, cost/health dashboard и migration layer для local/open-source/foreign providers. Платёжный аргумент: снизить зависимость от одного поставщика и сохранить управляемость on-premise AI-систем.

### Best global opportunity

**Vendor-neutral Agent Control Plane.**

```text
Beachhead market
↓
США/Канада, AI-native SaaS с 20–200 внутренними агентами
↓
Первая боль
↓
Компания не знает, какие агенты имеют какие tools/permissions и кто за них отвечает
↓
MVP
↓
Open-source CLI discovers agents + MCP/tools + identities + ownership gaps
↓
Paid wedge
↓
Over-permission detection, policy-as-code, remediation workflow and audit trail
↓
Regional layers
↓
US: runtime security/cost; EU: audit/data residency; RU: on-prem/model portability
```

Если вкладывать собственные деньги и 12 месяцев работы только в один продукт, я бы строил именно этот control plane. Причина не в модности agentic AI, а в сочетании пяти факторов: **evidence of pain** уже виден в adoption/incident/ownership data; **willingness to pay** привязан к security и compliance budgets; **timing** обусловлен переходом к multi-agent и MCP/A2A ecosystems; существующие решения фрагментированы между observability, GRC и IAM; **defensibility** может строиться на historical agent graph, permission-risk knowledge base, integrations и runtime evidence.

## Следующие шаги customer discovery

До полноценного продукта необходимо провести 30–40 интервью: 12–15 в США/Канаде, 10–12 в Европе и 8–10 в России. Нельзя спрашивать «нужна ли вам платформа для AI-агентов». Нужно просить показать последний incident, последний deployment, список tools, способ учёта spend, owner registry, eval pipeline и audit request.

| Проверяемая гипотеза | Минимальный сигнал подтверждения |
|---|---|
| У компании есть неизвестные или неинвентаризированные агенты | 30%+ интервьюируемых не могут за 30 минут показать полный список |
| Есть permission/identity gap | 5+ компаний показывают shared credentials, broad scopes или отсутствие attribution |
| Есть бюджет | 5+ ICP называют существующий budget owner и готовы к paid pilot |
| MVP можно внедрить без сложной платформы | 3 design partners подключают CLI к реальному repo/trace за неделю |
| Россия не просто копирует OSS | 3+ крупных компании готовы обсуждать on-prem license/support, а не только «напишем сами» |
| Европа платит за evidence, а не за dashboard | 5+ компаний показывают ручной audit/compliance workflow и называют срок/стоимость |

## References

[1]: https://cloudsecurityalliance.org/artifacts/enterprise-ai-security-starts-with-ai-agents "Cloud Security Alliance — Enterprise AI Security Starts with AI Agents"

[2]: https://cleanlab.ai/ai-agents-in-production-2025/ "Cleanlab — Engineering Leaders Survey: AI Agents in Production 2025"

[3]: https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai "European Commission — AI Act"

[4]: https://www.cbr.ru/fintech/primenenie-iskusstvennogo-intellekta-na-finansovom-rynke/ "Банк России — Искусственный интеллект на финансовом рынке"

[5]: https://yakovpartners.com/publications/ai-2025/ "Yakov and Partners / Yandex — Artificial intelligence in Russia: 2025"

[6]: https://arize.com/ "Arize — AI engineering platform for agents"

[7]: https://langfuse.com/blog/2024-07-ai-agent-observability-with-langfuse "Langfuse — AI Agent Observability, Tracing & Evaluation"

[8]: https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization "Model Context Protocol — Authorization specification"

[9]: https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/ "Google Developers Blog — Announcing the Agent2Agent Protocol"

[10]: https://zenity.io/blog/security/ai-agent-governance "Zenity — AI Agent Governance: The CISO Checklist"

[11]: https://prompt.security/ai-security-startup-map "Prompt Security / SentinelOne — AI Security Startup Map"

[12]: https://www.obsidiansecurity.com/blog/ai-agent-market-landscape "Obsidian Security — The 2025 AI Agent Security Landscape"
