# Рабочие заметки: TAM/SAM/SOM и design partners

## Официальные источники

- U.S. Census SUSB: ежегодная серия по establishments с оплачиваемыми сотрудниками, включает число firms/establishments, employment и payroll; актуальная страница указывает latest data 2022 и назначение для сегментации по industry и enterprise size. Источник: https://www.census.gov/programs-surveys/susb.html
- Statistics Canada, Software development and computer services 2024: software publishers reported C$27.9bn operating revenue in 2024, +15.6% y/y; broader computer systems design and related services generated C$113.0bn. Источник: https://www150.statcan.gc.ca/n1/daily-quotidien/260311/dq260311c-eng.htm
- Google A2A announcement: named ecosystem partners include Atlassian, Box, Cohere, Intuit, LangChain, MongoDB, PayPal, Salesforce, SAP, ServiceNow, UKG, Workday, Accenture, BCG, Capgemini, Cognizant, Deloitte, HCLTech, Infosys, KPMG, McKinsey, PwC and Wipro, plus additional technology partners. These are candidate design partners only, not confirmed leads.

## Modeling discipline

Use bottom-up logo × tiered ASP × penetration × win-rate. Do not use flat global share. For new categories, show a practical buying-universe view rather than pretending a published market headline exactly matches the product boundary. Clearly distinguish TAM (all accounts that could theoretically buy), SAM (geography/segment/product-fit filtered accounts), and SOM (accounts realistically reachable/winnable in five years). All figures are scenario estimates and should be labeled as such.
