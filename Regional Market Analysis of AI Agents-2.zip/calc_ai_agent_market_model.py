from dataclasses import dataclass

regions = {
    'North America': {'Enterprise':1500,'Mid-market':4500,'Growth':6000},
    'Europe': {'Enterprise':1200,'Mid-market':5000,'Growth':7800},
    'Russia': {'Enterprise':250,'Mid-market':900,'Growth':1350},
}

@dataclass
class Product:
    name: str
    asp: dict
    penetration: dict
    win_rate: dict
    gross_margin: float
    cac: dict
    onboarding: dict
    support_per_customer: dict

products = [
    Product('Agent Control Plane', {'Enterprise':100000,'Mid-market':30000,'Growth':10000}, {'North America':.25,'Europe':.22,'Russia':.15}, {'Enterprise':.10,'Mid-market':.07,'Growth':.04}, .88, {'Enterprise':70000,'Mid-market':25000,'Growth':8000}, {'Enterprise':25000,'Mid-market':8000,'Growth':2000}, {'Enterprise':12000,'Mid-market':5000,'Growth':1500}),
    Product('MCP Security Gateway', {'Enterprise':130000,'Mid-market':40000,'Growth':12000}, {'North America':.20,'Europe':.18,'Russia':.12}, {'Enterprise':.08,'Mid-market':.06,'Growth':.035}, .86, {'Enterprise':90000,'Mid-market':35000,'Growth':10000}, {'Enterprise':35000,'Mid-market':12000,'Growth':3000}, {'Enterprise':15000,'Mid-market':6500,'Growth':1800}),
    Product('Agent Regression CI', {'Enterprise':80000,'Mid-market':24000,'Growth':8000}, {'North America':.22,'Europe':.18,'Russia':.10}, {'Enterprise':.09,'Mid-market':.06,'Growth':.035}, .90, {'Enterprise':55000,'Mid-market':18000,'Growth':6000}, {'Enterprise':15000,'Mid-market':5000,'Growth':1500}, {'Enterprise':8000,'Mid-market':3500,'Growth':1200}),
]

for p in products:
    tam = sam = som = 0
    by_region=[]
    for r, tiers in regions.items():
        rtam = rsam = rsom = 0
        for tier, logos in tiers.items():
            t = logos * p.asp[tier]
            s = logos * p.penetration[r] * p.asp[tier]
            o = logos * p.penetration[r] * p.win_rate[tier] * p.asp[tier]
            tam += t; sam += s; som += o
            rtam += t; rsam += s; rsom += o
        by_region.append((r, rtam, rsam, rsom))
    # blended won ACV across target customers weighted by SOM mix
    won_logos = sum(regions[r][tier] * p.penetration[r] * p.win_rate[tier] for r in regions for tier in regions[r])
    weighted_acv = som / won_logos
    blended_cac = sum(regions[r][tier] * p.penetration[r] * p.win_rate[tier] * p.cac[tier] for r in regions for tier in regions[r]) / won_logos
    blended_onboarding = sum(regions[r][tier] * p.penetration[r] * p.win_rate[tier] * p.onboarding[tier] for r in regions for tier in regions[r]) / won_logos
    blended_support = sum(regions[r][tier] * p.penetration[r] * p.win_rate[tier] * p.support_per_customer[tier] for r in regions for tier in regions[r]) / won_logos
    annual_gross_profit = weighted_acv * p.gross_margin
    payback_months = (blended_cac + blended_onboarding) / ((annual_gross_profit - blended_support) / 12)
    print(p.name)
    print('TAM', round(tam/1e6,1), 'SAM5Y', round(sam/1e6,1), 'SOM5Y', round(som/1e6,1), 'won logos', round(won_logos))
    for x in by_region: print(x[0], round(x[1]/1e6,1), round(x[2]/1e6,1), round(x[3]/1e6,1))
    print('weighted ACV', round(weighted_acv), 'blended CAC', round(blended_cac), 'onboarding', round(blended_onboarding), 'support/yr', round(blended_support), 'payback months', round(payback_months,1))
    print()

# 5-year base ramp of realized logos (fraction of 5y SOM target)
ramp = {'Year 1':.08,'Year 2':.20,'Year 3':.38,'Year 4':.65,'Year 5':1.00}
for p in products:
    som=0
    for r, tiers in regions.items():
        for tier, logos in tiers.items(): som += logos * p.penetration[r] * p.win_rate[tier] * p.asp[tier]
    print(p.name, {y:round(som*f/1e6,1) for y,f in ramp.items()})

# scenarios by changing 5y penetration and win rates together
for p in products:
    base_tam=sum(logos*p.asp[tier] for r in regions for tier,logos in regions[r].items())
    base_sam=sum(logos*p.penetration[r]*p.asp[tier] for r in regions for tier,logos in regions[r].items())
    base_som=sum(logos*p.penetration[r]*p.win_rate[tier]*p.asp[tier] for r in regions for tier,logos in regions[r].items())
    for label, mult in [('Bear',.75),('Base',1.0),('Bull',1.25)]:
        print(p.name,label, 'SAM',round(base_sam*mult/1e6,1),'SOM',round(base_som*mult*mult/1e6,1))
