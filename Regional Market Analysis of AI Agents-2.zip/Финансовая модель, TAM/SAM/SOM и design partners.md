# Финансовая модель, TAM/SAM/SOM и design partners

**Дата:** 14 августа 2026 года  
**Продукты:** Agent Control Plane, MCP Security Gateway, Agent Regression CI  
**Валюта:** USD, если не указано иное

> **Дисклеймер.** Я не лицензированный финансовый консультант. Ниже приведена рабочая модель для продуктового планирования и проверки стартап-гипотез, а не гарантированный финансовый прогноз или инвестиционная рекомендация.

## 1. Как читать модель

Для новых категорий agent infrastructure нет единого надёжного отраслевого счётчика, который точно соответствовал бы границам трёх MVP. Поэтому основная оценка сделана **bottom-up**: количество потенциальных логотипов × tiered ACV × penetration. Это более консервативно и проверяемо, чем брать широкий headline «рынок AI» и приписывать ему долю.

США и Канада моделируются как North America, Европа — как EU/UK/Switzerland/Nordics/DACH/France/Benelux в совокупности, Россия — отдельно. В качестве sanity check используются официальные статистические источники: Census SUSB подтверждает возможность сегментации американских фирм по отрасли и размеру предприятия [1]; Statistics Canada сообщает о C$27,9 млрд выручки канадских software publishers и C$113,0 млрд в более широком computer systems design and related services в 2024 году [2]. Эти данные не являются прямым TAM для продуктов, а ограничивают порядок величины потенциальной базы.

## 2. Определение рынка

| Термин | Определение в этой модели |
|---|---|
| TAM | Все компании в выбранном software/platform/regulated-enterprise universe, которые теоретически могут покупать соответствующий продукт при полном проникновении категории |
| SAM | Часть TAM, которая за пять лет имеет production agent use case и достаточную сложность stack для конкретного MVP |
| SOM | Часть SAM, которую новая компания реалистично может выиграть за пять лет с небольшой командой, ограниченным GTM и учётом конкуренции |
| Design partner | Компания, согласная предоставить реальные workflows, traces/configuration или feedback и пройти совместный pilot; это не обязательно будущий платный клиент |

### Logo universe

| Регион | Enterprise | Mid-market | Growth/AI-native | Всего |
|---|---:|---:|---:|---:|
| North America | 1 500 | 4 500 | 6 000 | 12 000 |
| Europe | 1 200 | 5 000 | 7 800 | 14 000 |
| Russia | 250 | 900 | 1 350 | 2 500 |
| **Итого** | **2 950** | **10 400** | **15 150** | **28 500** |

Это не перепись всех компаний региона. Это **serviceable logo universe** — отобранная база software, SaaS, fintech, e-commerce, developer-tooling, enterprise IT и regulated companies, где есть достаточная вероятность собственной агентной разработки. В полном investor-grade diligence этот список нужно заменить на deduplicated account database с employee count, sector, AI hiring, MCP/agent signals и verified tech stack.

## 3. Pricing и unit economics

### Базовые ACV

| Продукт | Enterprise ACV | Mid-market ACV | Growth/AI-native ACV | Средняя gross margin |
|---|---:|---:|---:|---:|
| Agent Control Plane | $100k | $30k | $10k | 88% |
| MCP Security Gateway | $130k | $40k | $12k | 86% |
| Agent Regression CI | $80k | $24k | $8k | 90% |

ACV включает subscription и базовый support, но не крупные one-off implementation services. Enterprise ACV предполагает SSO/RBAC, private deployment, policy customization, retention и support. Growth ACV предполагает self-serve или assisted self-serve с ограниченным количеством агентов, tools или test runs.

### Unit economics

| Метрика | Agent Control Plane | MCP Security Gateway | Agent Regression CI |
|---|---:|---:|---:|
| Weighted ACV по выигранным клиентам | $35,4k | $44,8k | $28,7k |
| Blended CAC | $26,9k | $34,9k | $20,6k |
| Средний onboarding cost | $8,9k | $12,5k | $5,6k |
| Annual support/hosting на клиента | $5,0k | $6,2k | $3,5k |
| Gross margin | 88% | 86% | 90% |
| CAC + onboarding payback | 16,4 мес. | 17,6 мес. | 14,1 мес. |
| Целевой net revenue retention | 110–120% | 108–118% | 105–115% |
| Основной экономический риск | Длинный security procurement | Latency, reliability и 24/7 support | Commoditization и model-provider dependency |

Payback рассчитан как `(CAC + onboarding) / monthly contribution margin`, где contribution margin учитывает gross profit от ACV за вычетом среднего ежегодного support/hosting. Для раннего стартапа это допустимый, но не идеальный уровень: целевой ориентир после product-market fit — менее 12 месяцев. Следовательно, pricing и onboarding всех трёх продуктов нужно улучшать через стандартизированный deployment, self-serve discovery и product-led distribution.

## 4. TAM/SAM/SOM: базовый сценарий

### Итог по продуктам

| Продукт | TAM | SAM, 5 лет | SOM, 5 лет | SOM как % TAM | Ориентир выигранных логотипов |
|---|---:|---:|---:|---:|---:|
| Agent Control Plane | **$758,5 млн** | **$172,6 млн** | **$13,1 млн** | 1,7% | 370 |
| MCP Security Gateway | **$981,3 млн** | **$180,5 млн** | **$11,4 млн** | 1,2% | 255 |
| Agent Regression CI | **$606,8 млн** | **$116,1 млн** | **$7,8 млн** | 1,3% | 270 |

SOM не является прогнозом выручки конкретной команды. Это пятигодичный **reachable ARR ceiling** при выбранном ICP, региональном охвате и реалистичной win rate. Фактическая выручка может быть существенно ниже, если founders не смогут получить enterprise distribution или продукт окажется сложнее во внедрении.

### Региональная раскладка

| Продукт и регион | TAM | SAM, 5 лет | SOM, 5 лет |
|---|---:|---:|---:|
| Control Plane — North America | $345,0 млн | $86,2 млн | $6,7 млн |
| Control Plane — Europe | $348,0 млн | $76,6 млн | $5,6 млн |
| Control Plane — Russia | $65,5 млн | $9,8 млн | $0,7 млн |
| MCP Gateway — North America | $447,0 млн | $89,4 млн | $5,8 млн |
| MCP Gateway — Europe | $449,6 млн | $80,9 млн | $5,0 млн |
| MCP Gateway — Russia | $84,7 млн | $10,2 млн | $0,6 млн |
| Regression CI — North America | $276,0 млн | $60,7 млн | $4,2 млн |
| Regression CI — Europe | $278,4 млн | $50,1 млн | $3,2 млн |
| Regression CI — Russia | $52,4 млн | $5,2 млн | $0,3 млн |

Россия даёт меньший dollar TAM из-за регионального ACV discount и меньшего universe, но может быть удобным design-partner рынком для on-premise validation. В основной cloud business model её не следует смешивать с North America и Europe.

### Penetration и win rate assumptions

| Продукт | Target SAM penetration к Year 5: NA / EU / RU | Win rate Enterprise / Mid / Growth |
|---|---|---|
| Control Plane | 25% / 22% / 15% | 10% / 7% / 4% |
| MCP Gateway | 20% / 18% / 12% | 8% / 6% / 3,5% |
| Regression CI | 22% / 18% / 10% | 9% / 6% / 3,5% |

Penetration означает долю компаний с достаточно зрелым и актуальным use case, а не долю всей экономики. Win rates находятся в диапазоне, совместимом с новой B2B-компанией в конкурентном рынке; они не предполагают доминирования.

## 5. Сценарный анализ

Сценарии варьируют penetration и win rate. В Bear оба параметра снижены на 25%; в Bull penetration увеличена на 25%, а win rate — на 25%. Это не означает, что вся потенциальная база автоматически станет клиентами.

| Продукт | Bear SAM | Base SAM | Bull SAM | Bear SOM | Base SOM | Bull SOM |
|---|---:|---:|---:|---:|---:|---:|
| Agent Control Plane | $129,5 млн | $172,6 млн | $215,8 млн | $7,4 млн | $13,1 млн | $20,5 млн |
| MCP Security Gateway | $135,4 млн | $180,5 млн | $225,6 млн | $6,4 млн | $11,4 млн | $17,8 млн |
| Agent Regression CI | $87,1 млн | $116,1 млн | $145,1 млн | $4,4 млн | $7,8 млн | $12,1 млн |

Самая чувствительная переменная для Control Plane — не общий размер AI-рынка, а **доля компаний, которые уже имеют больше нескольких production agents и готовы подключить discovery tooling**. Для MCP Gateway это наличие достаточного MCP traffic и готовность поставить inline proxy. Для Regression CI — готовность команд превращать traces в release gates вместо ручных evals.

## 6. Ориентир ARR ramp на пять лет

| Продукт | Year 1 | Year 2 | Year 3 | Year 4 | Year 5 SOM endpoint |
|---|---:|---:|---:|---:|---:|
| Agent Control Plane | $0,7 млн | $1,6 млн | $3,3 млн | $6,6 млн | $13,1 млн |
| MCP Security Gateway | $0,6 млн | $1,4 млн | $2,9 млн | $5,7 млн | $11,4 млн |
| Agent Regression CI | $0,4 млн | $0,9 млн | $2,0 млн | $3,9 млн | $7,8 млн |

Это ramp до потенциально достижимого SOM, а не обещание. Для первого года разумнее планировать более узкую операционную цель: 3–5 paid pilots, $100k–300k exit ARR и доказанный repeatable deployment. Если команда сразу закладывает $700k+ ARR в Year 1, это потребует unusually strong founder distribution или нескольких enterprise contracts.

## 7. Сравнение финансовой привлекательности

### Agent Control Plane — лучший риск/доходность

У него второй по размеру TAM, но лучший стартовый wedge: read-only CLI не вмешивается в production traffic и способен быстро показать findings. У продукта сильный security/governance budget owner и потенциально высокая expansion revenue: inventory может расширяться в MCP policy, lifecycle, runtime action control и audit evidence.

Финансовый риск — длинный enterprise cycle и overlap с Zenity, Prompt Security, GRC, IAM и observability vendors. Поэтому первые 12 месяцев нужно продавать не «платформу управления всеми агентами», а paid discovery/security assessment с автоматическим remediation workflow.

### MCP Security Gateway — самый высокий ACV, но более сложный delivery

Gateway потенциально имеет самый высокий ACV и сильный security buyer, но требует доверия к inline deployment, высокой доступности и низкой latency. Один production incident может разрушить доверие. Gross margin ниже из-за support, deployment и customer-specific policy work.

Финансово это хороший второй продукт или enterprise wedge после того, как Control Plane уже знает inventory и tool graph. Строить Gateway первым стоит только при наличии design partner с реальным MCP traffic и готовностью поставить proxy.

### Agent Regression CI — самый быстрый self-serve, но меньший потолок

Regression CI имеет лучший payback в базовой модели и наиболее удобную OSS/GitHub distribution. Однако evals и observability уже имеют сильные продукты, а часть функций может постепенно встраиваться в model platforms. Поэтому нужно занимать narrow position: **production failure → reproducible golden test → release gate**, а не «универсальная оценка качества AI».

## 8. Рекомендованный финансовый порядок запуска

| Этап | Продукт | Финансовая цель |
|---|---|---|
| 0–3 мес. | Control Plane CLI | 10 design partners, 3 paid pilots, $50k–100k contracted ARR |
| 4–9 мес. | Control Plane SaaS/private pilot | $150k–300k exit ARR, payback <18 мес. |
| 7–15 мес. | MCP Gateway module | 2 enterprise deployments, $100k+ ACV each |
| 10–18 мес. | Regression CI integration | OSS adoption, $200k+ expansion ARR |

## 9. Design partners для Agent Control Plane

Ниже приведён **потенциальный shortlist**, а не утверждение, что компании уже согласны участвовать. Приоритет отдаётся организациям, где одновременно вероятны: большое количество внутренних или customer-facing agents, сложный tool/integration graph, собственная platform/security team, публичный интерес к agent interoperability или высокая цена ошибки.

### Tier A: первые 10 целей

| Приоритет | Компания | Почему подходит | Предполагаемый champion | Pilot wedge |
|---:|---|---|---|---|
| 1 | **Replit** | AI-native product с агентной разработкой и сложными tool/runtime workflows | VP/Head of AI Engineering, Platform lead | Inventory agents, tools, identities и production environments |
| 2 | **Sourcegraph** | Developer tooling и coding-agent workflows, высокая чувствительность к permissions и code access | Head of Platform/Security, AI engineering | Agent-to-repo permission graph и kill path |
| 3 | **Vercel** | Большая developer platform ecosystem и много integrations/tools | AI SDK/platform lead, security architect | Discover agents/MCP integrations across preview/production |
| 4 | **Ramp** | Fintech workflows, где agent actions затрагивают sensitive financial systems | Head of AI, CISO, platform engineering | Inventory + finance-tool ownership + approval gaps |
| 5 | **Intercom** | Customer support automation с высокой стоимостью silent failures и data access | Head of AI/Automation, security | Agent inventory и sensitive-data/tool mapping |
| 6 | **Zapier** | Много automation workflows и integrations; natural fit для tool/agent graph | Platform/security, AI product lead | Discover duplicated agents, integrations and owners |
| 7 | **Retool** | Internal tools and workflows create broad surface of custom agents and permissions | CTO/Platform lead, security engineering | Scan internal apps, workflows and service accounts |
| 8 | **Datadog** | Публичный интерес к MCP and AI-assisted developer workflows; может быть customer или ecosystem partner | AI platform, developer productivity, security | Agent/tool inventory plus OTel correlation |
| 9 | **Elastic** | Security/search/observability expertise and agentic integrations; strong technical design partner | Security engineering, observability platform | Cross-platform inventory and risk graph |
| 10 | **Harness** | DevOps/platform engineering context, deployment and runtime control are core | Platform engineering, AI/DevSecOps | Agent lifecycle from CI/CD to production |

### Tier B: 12 дополнительных целей

| Компания | Fit | Почему включать в outreach |
|---|---|---|
| **Atlassian** | High | A2A ecosystem partner; many enterprise workflows and integrations |
| **ServiceNow** | High | Agentic enterprise workflows and cross-system action surface |
| **Salesforce** | High | CRM data, tools, permissions and agent governance are central |
| **MongoDB** | High | Data platform plus A2A ecosystem signal; useful for data/tool graph design |
| **Box** | Medium/High | Document/data access and agent permissions create clear governance wedge |
| **Intuit** | High | Financial workflows and agent action controls |
| **PayPal** | High | Sensitive financial operations and machine identity requirements |
| **SAP** | High | Large regulated enterprise workflows; likely slower procurement |
| **Workday** | High | HR data and high-sensitivity access; strong governance use case |
| **UKG** | Medium/High | Workforce/HR agent workflows and privacy-sensitive data |
| **Glean** | High | Enterprise knowledge/search agents and permission-aware data access |
| **Pinecone / Weaviate** | Medium | AI infrastructure ecosystem; potential technical partners and design references |

Google’s official A2A announcement names Atlassian, Box, Cohere, Intuit, LangChain, MongoDB, PayPal, Salesforce, SAP, ServiceNow, UKG, Workday and a broad set of technology and consulting partners [3]. This is useful as a public signal of agent-interoperability activity, but not proof that every named company is a qualified buyer. The shortlist above therefore separates strong product fit from likely access and procurement difficulty.

## 10. Кого не ставить в первый outreach

Не стоит начинать с Microsoft, Google, Amazon, OpenAI или Anthropic: они имеют собственные platform/security roadmaps, сложный procurement и высокий риск, что разговор превратится в competitive intelligence без pilot. Не стоит также начинать с крупнейших банков и телекомов, если у команды нет enterprise security references: pain там высок, но onboarding и vendor review могут занять 6–12 месяцев.

LangChain, Langfuse, Arize и Braintrust полезны как ecosystem/channel conversations, но часть из них потенциально пересекается с Regression CI и observability. Для Control Plane их лучше рассматривать как integration partners или technical advisors, а не как единственный buyer ICP.

## 11. Как формулировать предложение design partner

Первое сообщение должно продавать не «AI governance platform», а короткий бесплатный или low-cost diagnostic:

> «За 60 минут подключим read-only scanner к одному репозиторию и MCP/configuration source. Вернём карту агентов, tools, identities и owners, а также список конкретных permission и inventory gaps с evidence. Ничего не меняем в production и не забираем secret values. Взамен просим 45 минут feedback и разрешение обсудить paid pilot, если findings полезны.»

### Предлагаемый pilot package

| Элемент | Содержание |
|---|---|
| Длительность | 2 недели |
| Scope | 1 команда, 1–3 репозитория, 1 Kubernetes environment, до 25 агентов |
| Доступ | Read-only GitHub/GitLab, manifests, MCP config, optional OTel metadata |
| Deliverables | Inventory, owner map, identity/tool graph, top-10 findings, remediation backlog |
| Безопасность | Secret values не извлекаются; payloads redacted; self-hosted runner option |
| Success metric | Найти минимум 3 неизвестных или materially risky relationships |
| Цена | Бесплатно для первых 3 design partners; затем $5k–15k paid pilot |

## 12. Приоритизированный порядок контактов

Первая волна должна включать **Replit, Sourcegraph, Vercel, Ramp, Intercom, Zapier, Retool, Datadog, Elastic и Harness**. Она балансирует техническую доступность, agent maturity, security urgency и возможность получить качественный feedback без банковского procurement.

Вторая волна — Atlassian, ServiceNow, Salesforce, MongoDB, Box и Glean. Они сильнее как enterprise references, но вероятнее потребуют security review, procurement и formal vendor onboarding.

Третья волна — SAP, Workday, UKG, PayPal и Intuit. У них высокая потенциальная ценность и сильные regulated use cases, но цикл сделки и требования к доказательствам будут существенно выше.

## 13. Главный вывод

По финансовой модели лучшая первая ставка — **Agent Control Plane**. Его базовый TAM оценивается примерно в **$759 млн**, пятилетний SAM — в **$173 млн**, а реалистичный five-year SOM ceiling — около **$13 млн ARR**. MCP Security Gateway имеет больший TAM и ACV, но более тяжёлый deployment и support burden. Agent Regression CI проще распространять через OSS и имеет лучший payback, но обладает меньшим SAM и более высоким риском commoditization.

Рекомендуемая стратегия — не выбирать три независимых продукта. Нужно использовать Control Plane как входной продукт, затем расшириться в MCP Security Gateway после появления tool graph, а Regression CI добавить как lifecycle module, когда накопятся реальные traces и incidents. Это снижает initial build risk и позволяет одному account постепенно расширять ARR.

## References

[1]: https://www.census.gov/programs-surveys/susb.html "U.S. Census Bureau — Statistics of U.S. Businesses"

[2]: https://www150.statcan.gc.ca/n1/daily-quotidien/260311/dq260311c-eng.htm "Statistics Canada — Software development and computer services, 2024"

[3]: https://developers.googleblog.com/en/a2a-a-new-era-of-agent-interoperability/ "Google Developers Blog — Announcing the Agent2Agent Protocol"

[4]: https://cloudsecurityalliance.org/artifacts/enterprise-ai-security-starts-with-ai-agents "Cloud Security Alliance — Enterprise AI Security Starts with AI Agents"

[5]: https://cleanlab.ai/ai-agents-in-production-2025/ "Cleanlab — Engineering Leaders Survey: AI Agents in Production 2025"

[6]: https://arize.com/ "Arize — AI engineering platform for agents"

[7]: https://langfuse.com/blog/2024-07-ai-agent-observability-with-langfuse "Langfuse — AI Agent Observability, Tracing & Evaluation"

[8]: https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization "Model Context Protocol — Authorization specification"
